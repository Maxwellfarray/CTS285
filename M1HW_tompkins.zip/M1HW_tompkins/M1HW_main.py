selector = ''
while(selector != "5"):
    selector = input('Please enter a number to select an option.\n1. Addition\n2. Subtration\n3. Devision\n4. Multiplication\n5. Exit\n\nInput:')
    import M1HW_AddModule 
    match selector:
        case "1":
            M1HW_AddModule.add()
        case "2":
            M1HW_AddModule.sub()
        case "3":
            M1HW_AddModule.dev()
        case "4":
            M1HW_AddModule.mult()
        case "5":
            print('Bye!')
        case other:
            print("Unrecognized input.")
   
