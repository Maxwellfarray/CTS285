import M1HW_InputModule
def add():
   rep = "1"
   while (rep != '2'):
       numbOne, numbTwo = M1HW_InputModule.get()
       result = int(numbOne) + int(numbTwo)
       print(str(numbOne) + " + " + str(numbTwo) + " = " + str(result))
       rep = input('1. Repeat\n2. Main Menue\n')
def sub():
    rep = "1"
    while (rep != '2'):
        numbOne, numbTwo = M1HW_InputModule.get()
        result = int(numbOne) - int(numbTwo)
        print(str(numbOne) + " - " + str(numbTwo) + " = " + str(result))
        rep = input('1. Repeat\n2. Main Menue\n')
def mult():
    rep = "1"
    while (rep != '2'):
        numbOne, numbTwo = M1HW_InputModule.get()
        result = int(numbOne) * int(numbTwo)
        print(str(numbOne) + " * " + str(numbTwo) + " = " + str(result))
        rep = input('1. Repeat\n2. Main Menue\n')
def dev():
    rep = "1"
    while (rep != '2'):
        numbOne, numbTwo = M1HW_InputModule.get()
        result = int(numbOne) / int(numbTwo)
        print(str(numbOne) + " / " + str(numbTwo) + " = " + str(result))
        rep = input('1. Repeat\n2. Main Menue\n')
    