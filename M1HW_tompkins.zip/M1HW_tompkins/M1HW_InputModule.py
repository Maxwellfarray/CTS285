# -*- coding: utf-8 -*-
"""
Created on Sat Aug 26 15:47:56 2023

@author: trent
"""

def get():
  numbOne = input('Enter first number: ')
  numbTwo = input('Enter second number: ')
  return numbOne, numbTwo
    