# -*- coding: utf-8 -*
#Joshua and Trent
passing = 0
while (passing == 0):
    passing = 1
    check = input('Do you have python 3.11? please enter "Yes" or "No": ')
    if(check != "Yes" and check != "No"):
        passing = 0
        print('Please enter "Yes" or "No".')
# for some reason its running the main on import. No clue why. dont have time to fix it
if (check == "Yes"):
    import M1HW_main
else:
    print("Please get python 3.11 to run our Calulator.")