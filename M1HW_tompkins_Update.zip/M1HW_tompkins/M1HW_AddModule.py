import M1HW_InputModule
# Addintion calculation
def add():
   rep = 1
   while (rep != 2):
       numbOne, numbTwo = M1HW_InputModule.get()
       result = int(numbOne) + int(numbTwo)
       print(str(numbOne) + " + " + str(numbTwo) + " = " + str(result))
       passing = 0
       while (passing == 0):
           passing = 1
           rep = input('1. Repeat\n2. Main Menue\n')
           passing = M1HW_InputModule.passForNumber(rep)
           if (passing != 0):
               rep = int(rep)
               if (rep != 1 and rep != 2):
                   passing = 0
                   print('Please enter 1 or 2.')
# Subtraction caclulation
def sub():
    rep = 1
    while (rep != 2):
        numbOne, numbTwo = M1HW_InputModule.get()
        result = int(numbOne) - int(numbTwo)
        print(str(numbOne) + " - " + str(numbTwo) + " = " + str(result))
        passing = 0
        while (passing == 0):
            passing = 1
            rep = input('1. Repeat\n2. Main Menue\n')
            passing = M1HW_InputModule.passForNumber(rep)
            if (passing != 0):
                rep = int(rep)
                if (rep != 1 and rep != 2):
                    passing = 0
                    print('Please enter 1 or 2.')
        
# Multiplication calculation
def mult():
    rep = 1
    while (rep != 2):
        numbOne, numbTwo = M1HW_InputModule.get()
        result = int(numbOne) * int(numbTwo)
        print(str(numbOne) + " * " + str(numbTwo) + " = " + str(result))
        passing = 0
        while (passing == 0):
            passing = 1
            rep = input('1. Repeat\n2. Main Menue\n')
            passing = M1HW_InputModule.passForNumber(rep)
            if (passing != 0):
                rep = int(rep)
                if (rep != 1 and rep != 2):
                    passing = 0
                    print('Please enter 1 or 2.')
# Devision calculation
def dev():
    rep = 1
    while (rep != 2):
        numbOne, numbTwo = M1HW_InputModule.get()
        result = int(numbOne) / int(numbTwo)
        print(str(numbOne) + " / " + str(numbTwo) + " = " + str(result))
        passing = 0
        while (passing == 0):
            passing = 1
            rep = input('1. Repeat\n2. Main Menue\n')
            passing = M1HW_InputModule.passForNumber(rep)
            if (passing != 0):
                rep = int(rep)
                if (rep != 1 and rep != 2):
                    passing = 0
                    print('Please enter 1 or 2.')
       
        

    